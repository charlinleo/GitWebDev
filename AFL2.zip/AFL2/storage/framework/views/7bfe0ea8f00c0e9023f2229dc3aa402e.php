<?php $__env->startSection('pagetitle'); ?>
<?php $__env->startSection('maintitle'); ?>
<?php $__env->startSection('layout_content'); ?>

    <body>
        <section class="page-section portfolio" id="portfolio">
            <div class="container">
                <h2 class="page-section-heading text-center text-uppercase text-secondary mb-0 mt-5">Review</h2>

                <div class="divider-custom">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <div class="masthead container p-3 mt-5">
                    <div class="card p-3">
                        <table class="table">
                            <thead class="thead-dark">
                                <tr>
                                    <th>NO</th>
                                    <th>USERNAME</th>
                                    <th>RATING</th>
                                    <th>COMMENT</th>
                                </tr>
                            </thead>
                            
                            <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->index + 1); ?></td>
                                    <td><?php echo e($review['nama']); ?></td>
                                    <td><?php echo e($review['rating']); ?></td>
                                    <td><?php echo e($review['comment']); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </section>
        <div class="copyright py-4 text-center text-white mt-5 mb-0">
            <div class="container"><small>Copyright &copy; Autosight</small></div>
        </div>
    </body>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/charlinleo/Documents/Laravel/webdev/GitWebDev/AFL2/resources/views/review.blade.php ENDPATH**/ ?>